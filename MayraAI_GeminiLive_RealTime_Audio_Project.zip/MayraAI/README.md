# Mayra AI — Android project with native Gemini Live audio

This is a source project prepared for a cloud Android build. It is **not a compiled or device-tested APK**.

## Real-time voice implementation
- Uses Gemini Live API over a persistent WebSocket session.
- Streams microphone PCM16 mono audio at 16 kHz directly to Gemini in ~100 ms chunks.
- Receives native PCM16 mono audio at 24 kHz and plays it through Android `AudioTrack`.
- Uses server-side voice activity detection, input/output transcription side channels, and flushes playback when Gemini reports an interruption.
- The Live path does **not** use Android SpeechRecognizer to turn the user's speech into text and then call text chat, and does **not** use Android Text-to-Speech for Gemini Live responses.
- Requests Android echo cancellation and noise suppression where supported. Echo control and latency depend on the phone's audio hardware and OS.

## Settings
In the app's side drawer:
- Enter your Gemini API key.
- `عام چیٹ ماڈل` is used for regular text chat.
- `Real-Time Live Voice ماڈل` defaults to `gemini-3.8-live` and is used for bidirectional native audio. If your key/account does not have access to that model, choose a Live API model available to your account.
- Choose a conversational mood and female/male voice preset. The Live API uses the selected Gemini prebuilt voice (`Aoede` for female-style and `Puck` for male-style); voice character and Urdu pronunciation are determined by the model and can vary.
- Choose `اصل Gemini Live گفتگو` and tap the microphone. The app asks for microphone permission if needed.

## API key safety
The API key is stored in the app's private local preferences and is passed to the Live WebSocket endpoint. This is suitable only for personal testing. Do not distribute this APK with a personal key embedded or stored in it. For a public release, use a backend that issues short-lived/ephemeral tokens, following Google's current Live API security guidance.

## Build using only an Android phone
1. Download and extract the ZIP.
2. Create a GitHub repository and upload the extracted project files (not only the ZIP), including `.github/workflows/android-apk.yml`.
3. Open **Actions** and run **Build Mayra AI APK**.
4. Download the `MayraAI-debug-apk` artifact from the successful workflow and extract `app-debug.apk`.
5. Install it on your Android device.

## Important limitations
- The source was updated for native bidirectional audio, but this environment does not have Gradle/Android SDK available, so the project has **not been compiled or tested on a physical phone here**. The first cloud build may reveal dependency/API or model-access issues that need fixing.
- Real-time behavior depends on Gemini Live API availability, model access, network, microphone permissions, and the phone's audio routing. No implementation can guarantee a perfectly human voice or zero latency.
- The default Live model is `gemini-3.8-live` based on the current Google Live API WebSocket getting-started documentation. Use a currently available Live model if this one is not enabled for your API key.
- Offline functionality remains limited to basic canned responses; Gemini Live requires internet access.
