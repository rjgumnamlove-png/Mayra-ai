package com.mayra.ai

import android.content.Context
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Process
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Gemini Live native bidirectional audio session.
 * Streams microphone PCM16/16kHz to Gemini and plays native PCM16/24kHz audio back.
 * No Android SpeechRecognizer -> text -> TTS conversion is used in this live path.
 */
class GeminiLiveSession(
    private val context: Context,
    private val apiKey: String,
    private val model: String,
    private val systemInstruction: String,
    private val voiceName: String,
    private val onStatus: (String, Boolean) -> Unit,
    private val onTranscript: (String, String) -> Unit,
    private val onTurnComplete: () -> Unit
) {
    private val active = AtomicBoolean(false)
    private val ready = AtomicBoolean(false)
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val previousAudioMode = audioManager.mode
    private val previousSpeakerphone = audioManager.isSpeakerphoneOn
    private val captureStarted = AtomicBoolean(false)
    private val playbackExecutor = Executors.newSingleThreadExecutor()
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var captureThread: Thread? = null
    @Volatile private var echoCanceler: AcousticEchoCanceler? = null
    @Volatile private var noiseSuppressor: NoiseSuppressor? = null

    fun start() {
        if (!active.compareAndSet(false, true)) return
        onStatus("Gemini Live سے رابطہ قائم ہو رہا ہے…", false)
        try {
            val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
            val request = Request.Builder().url(url + "?key=" + java.net.URLEncoder.encode(apiKey, "UTF-8")).build()
            socket = client.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    val generation = JSONObject()
                        .put("responseModalities", org.json.JSONArray().put("AUDIO"))
                        .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName))))
                    val setup = JSONObject().put("setup", JSONObject()
                        .put("model", if (model.startsWith("models/")) model else "models/$model")
                        .put("generationConfig", generation)
                        .put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", systemInstruction))))
                        .put("inputAudioTranscription", JSONObject().put("languageCodes", org.json.JSONArray().put("ur-PK")))
                        .put("outputAudioTranscription", JSONObject().put("languageCodes", org.json.JSONArray().put("ur-PK")))
                    )
                    webSocket.send(setup.toString())
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val root = JSONObject(text)
                        if (root.has("setupComplete")) {
                            ready.set(true)
                            createPlayback()
                            startCapture()
                            onStatus("Live گفتگو فعال ہے — آپ براہِ راست بات کریں", true)
                            return
                        }
                        if (root.has("error")) {
                            val message = root.optJSONObject("error")?.optString("message") ?: "Gemini Live API error"
                            onStatus("Gemini Live مسئلہ: $message", false)
                            return
                        }
                        val server = root.optJSONObject("serverContent") ?: return
                        if (server.optBoolean("interrupted", false)) {
                            try { track?.pause(); track?.flush(); track?.play() } catch (_: Exception) {}
                        }
                        val input = server.optJSONObject("inputTranscription") ?: server.optJSONObject("interimInputTranscription")
                        if (input != null) {
                            val t = input.optString("text", "")
                            if (t.isNotBlank()) onTranscript("user", t)
                        }
                        val output = server.optJSONObject("outputTranscription")
                        if (output != null) {
                            val t = output.optString("text", "")
                            if (t.isNotBlank()) onTranscript("assistant", t)
                        }
                        val parts = server.optJSONObject("modelTurn")?.optJSONArray("parts")
                        if (parts != null) {
                            for (i in 0 until parts.length()) {
                                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                                val b64 = inline.optString("data", "")
                                if (b64.isNotEmpty()) {
                                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                                    playbackExecutor.execute { playAudio(bytes) }
                                }
                            }
                        }
                        if (server.optBoolean("turnComplete", false)) onTurnComplete()
                    } catch (e: Exception) {
                        onStatus("Live جواب پڑھنے میں مسئلہ: ${e.message ?: "نامعلوم خرابی"}", false)
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    ready.set(false)
                    onStatus("Gemini Live کنکشن ناکام: ${t.message ?: "نیٹ ورک یا API Key چیک کریں"}", false)
                    stopInternal(closeSocket = false)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    ready.set(false)
                    onStatus("Live سیشن بند ہوگیا: $reason", false)
                    stopInternal(closeSocket = false)
                }
            })
        } catch (e: Exception) {
            onStatus("Live شروع نہیں ہو سکا: ${e.message ?: "خرابی"}", false)
            stopInternal(closeSocket = false)
        }
    }

    private fun createPlayback() {
        if (track != null) return
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val buffer = (if (min > 0) min else 48000).coerceAtLeast(48000)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(buffer)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track?.play()
    }

    private fun playAudio(bytes: ByteArray) {
        if (!active.get() || bytes.isEmpty()) return
        try {
            val audioTrack = track ?: return
            var offset = 0
            while (offset < bytes.size && active.get()) {
                val written = audioTrack.write(bytes, offset, bytes.size - offset, AudioTrack.WRITE_BLOCKING)
                if (written <= 0) break
                offset += written
            }
        } catch (_: Exception) { }
    }

    private fun startCapture() {
        if (!captureStarted.compareAndSet(false, true)) return
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferBytes = (if (min > 0) min else 6400).coerceAtLeast(6400)
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = true
            val audioRecord = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(16000)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
                .setBufferSizeInBytes(bufferBytes)
                .build()
            recorder = audioRecord
            if (AcousticEchoCanceler.isAvailable()) echoCanceler = AcousticEchoCanceler.create(audioRecord.audioSessionId)?.apply { enabled = true }
            if (NoiseSuppressor.isAvailable()) noiseSuppressor = NoiseSuppressor.create(audioRecord.audioSessionId)?.apply { enabled = true }
            audioRecord.startRecording()
            captureThread = Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                val shorts = ShortArray(1600) // 100 ms at 16 kHz
                while (active.get() && ready.get()) {
                    val count = try { audioRecord.read(shorts, 0, shorts.size, AudioRecord.READ_BLOCKING) } catch (_: Exception) { -1 }
                    if (count <= 0) continue
                    val bytes = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until count) bytes.putShort(shorts[i])
                    val message = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                        .put("mimeType", "audio/pcm;rate=16000")
                        .put("data", Base64.encodeToString(bytes.array(), Base64.NO_WRAP))))
                    if (socket?.send(message.toString()) != true) break
                }
            }.apply { name = "Mayra-GeminiLive-Mic"; start() }
        } catch (e: Exception) {
            onStatus("مائیکروفون شروع نہیں ہو سکا: ${e.message ?: "اجازت چیک کریں"}", false)
            captureStarted.set(false)
        }
    }

    fun stop() = stopInternal(closeSocket = true)

    @Synchronized private fun stopInternal(closeSocket: Boolean) {
        active.set(false)
        ready.set(false)
        try { if (closeSocket) socket?.close(1000, "User stopped live session") else socket?.cancel() } catch (_: Exception) {}
        socket = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { echoCanceler?.release() } catch (_: Exception) {}
        try { noiseSuppressor?.release() } catch (_: Exception) {}
        echoCanceler = null; noiseSuppressor = null
        captureThread = null
        captureStarted.set(false)
        try { track?.pause(); track?.flush(); track?.stop(); track?.release() } catch (_: Exception) {}
        track = null
        try { audioManager.isSpeakerphoneOn = previousSpeakerphone; audioManager.mode = previousAudioMode } catch (_: Exception) {}
        playbackExecutor.shutdownNow()
    }
}
