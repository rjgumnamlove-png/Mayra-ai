package com.mayra.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("mayra_settings", MODE_PRIVATE) }
    private val permissionCode = 410
    @Volatile private var liveMode = false
    @Volatile private var currentMood = "natural"
    @Volatile private var selectedVoice = "female"
    @Volatile private var pendingLiveStart = false
    private var liveSession: GeminiLiveSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentMood = prefs.getString("mood", "natural") ?: "natural"
        selectedVoice = prefs.getString("voice", "female") ?: "female"
        liveMode = false // Native Gemini Live starts only after the user taps the microphone.
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(Bridge(), "MayraNative")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ur", "PK")) ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (result < TextToSpeech.LANG_AVAILABLE) tts?.language = Locale("en", "US")
            applyVoicePreference()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) { if (liveMode) runOnUiThread { startListening() } }
                override fun onDone(utteranceId: String?) { if (liveMode) runOnUiThread { startListening() } }
            })
        }
    }

    private fun applyVoicePreference() {
        val engine = tts ?: return
        val voices = engine.voices ?: return
        val wantedLocale = voices.filter { it.locale.language == "ur" }
        val candidates = if (wantedLocale.isNotEmpty()) wantedLocale else voices.filter { it.locale.language == "en" }
        val chosen = when (selectedVoice) {
            "male" -> candidates.firstOrNull { it.name.contains("male", true) || it.name.contains("man", true) }
            else -> candidates.firstOrNull { it.name.contains("female", true) || it.name.contains("woman", true) }
        } ?: candidates.firstOrNull()
        if (chosen != null) engine.voice = chosen
    }

    inner class Bridge {
        @JavascriptInterface fun speak(text: String) { runOnUiThread { tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "mayra_reply") } }
        @JavascriptInterface fun listen() { liveMode = false; runOnUiThread { startListening() } }
        @JavascriptInterface fun startLive() { liveMode = true; runOnUiThread { startGeminiLive() } }
        @JavascriptInterface fun stopLive() { liveMode = false; pendingLiveStart = false; runOnUiThread { speechRecognizer?.cancel(); liveSession?.stop(); liveSession = null; webView.evaluateJavascript("window.onMayraLiveStatus('Live گفتگو بند ہوگئی', false)", null); webView.evaluateJavascript("window.onMayraListening(false)", null) } }
        @JavascriptInterface fun savePreferences(mood: String, voice: String, live: Boolean, thinking: String) {
            currentMood = mood.take(40); selectedVoice = voice.take(20); liveMode = live
            prefs.edit().putString("mood", currentMood).putString("voice", selectedVoice).putBoolean("live", liveMode).putString("thinking", thinking.take(20)).apply()
            applyVoicePreference()
        }
        @JavascriptInterface fun getPreferences(): String = JSONObject()
            .put("mood", prefs.getString("mood", "natural"))
            .put("voice", prefs.getString("voice", "female"))
            .put("live", prefs.getBoolean("live", false))
            .put("thinking", prefs.getString("thinking", "balanced")).toString()
        @JavascriptInterface fun saveApiSettings(endpoint: String, apiKey: String, model: String, liveModel: String) {
            prefs.edit().putString("endpoint", endpoint.trim()).putString("apiKey", apiKey.trim())
                .putString("model", model.trim()).putString("liveModel", liveModel.trim()).apply()
        }
        @JavascriptInterface fun getApiSettings(): String {
            return JSONObject().put("endpoint", prefs.getString("endpoint", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"))
                .put("apiKey", prefs.getString("apiKey", "")).put("model", prefs.getString("model", "gemini-2.5-flash"))
                .put("liveModel", prefs.getString("liveModel", "gemini-3.8-live")).toString()
        }
        @JavascriptInterface fun askAI(prompt: String) {
            executor.execute {
                val endpoint = prefs.getString("endpoint", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions") ?: ""
                val key = prefs.getString("apiKey", "") ?: ""
                val model = prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
                val mood = prefs.getString("mood", "natural") ?: "natural"
                val thinking = prefs.getString("thinking", "balanced") ?: "balanced"
                if (key.isBlank()) {
                    val reply = offlineReply(prompt)
                    runOnUiThread { sendReply(reply, true) }
                    return@execute
                }
                try {
                    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Authorization", "Bearer $key")
                        doOutput = true
                    }
                    val systemPrompt = moodInstruction(mood, thinking)
                    val history = mutableListOf<JSONObject>()
                    val savedHistory = prefs.getString("chatHistory", "[]") ?: "[]"
                    try {
                        val saved = JSONArray(savedHistory)
                        for (i in 0 until saved.length()) history.add(saved.getJSONObject(i))
                    } catch (_: Exception) { /* reset malformed local history */ }
                    history.add(JSONObject().put("role", "user").put("content", prompt))
                    while (history.size > 20) history.removeAt(0)
                    val messages = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
                    history.forEach { messages.put(it) }
                    val body = JSONObject().put("model", model).put("messages", messages).toString()
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                    val response = stream.bufferedReader().use { it.readText() }
                    if (conn.responseCode !in 200..299) throw Exception("API ${conn.responseCode}: ${response.take(250)}")
                    val reply = JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                    history.add(JSONObject().put("role", "assistant").put("content", reply))
                    while (history.size > 20) history.removeAt(0)
                    prefs.edit().putString("chatHistory", JSONArray(history).toString()).apply()
                    runOnUiThread { sendReply(reply, false) }
                } catch (e: Exception) {
                    runOnUiThread { sendReply("Online AI could not connect: ${e.message ?: "network error"}. Check your endpoint and API settings.", true) }
                }
            }
        }
    }

    private fun moodInstruction(mood: String, thinking: String): String {
        val style = when (mood) {
            "girlfriend" -> "Be affectionate, warm and lightly romantic while maintaining healthy boundaries; never claim to be a real human partner."
            "funny" -> "Be witty, playful and humorous when appropriate, without mocking the user."
            "serious" -> "Be a calm, thoughtful, serious female-presenting assistant; concise and respectful."
            "caring" -> "Be gentle, empathetic, encouraging and attentive, like a caring companion."
            else -> "Be natural, friendly and conversational."
        }
        val responseStyle = when (thinking) {
            "fast" -> "Prioritize a quick, concise answer. Avoid unnecessary detail."
            "deep" -> "Consider the question carefully and give a thoughtful, structured answer with useful details; do not reveal hidden chain-of-thought, only provide the conclusion and a brief rationale."
            else -> "Balance speed and detail; answer clearly with enough explanation."
        }
        return "You are Mayra AI, an AI assistant. Always answer in Urdu (Urdu script) unless the user explicitly requests another language. Use natural spoken Urdu, not stiff or robotic wording. Keep context from the conversation provided. $style $responseStyle For voice conversations, answer in short, speakable sentences. Be honest that you are AI if asked."
    }

    private fun offlineReply(prompt: String): String {
        val p = prompt.lowercase(Locale.ROOT)
        return when {
            p.contains("hello") || p.contains("hi") || p.contains("salam") || p.contains("السلام") -> "السلام علیکم! میں مائرہ اے آئی ہوں۔ آف لائن موڈ میں بنیادی مدد کر سکتی ہوں۔ مکمل AI کے لیے سائیڈ مینو میں Gemini API key شامل کریں۔"
            p.contains("time") || p.contains("waqt") -> "آف لائن موڈ میں میں تازہ وقت یا انٹرنیٹ کی معلومات کی تصدیق نہیں کر سکتی۔"
            p.contains("html") || p.contains("website") -> "ویب سائٹ بنانے کے لیے اپنا خیال لکھیں۔ مکمل AI ویب سائٹ بنانے کے لیے سائیڈ مینو میں Gemini API کنفیگر کریں۔"
            else -> "میں ابھی آف لائن موڈ میں ہوں۔ بنیادی سہولیات دستیاب ہیں؛ آن لائن AI کے لیے سائیڈ مینو میں Gemini API key اور ماڈل شامل کریں۔"
        }
    }

    private fun sendReply(reply: String, offline: Boolean) {
        val safe = JSONObject.quote(reply)
        webView.evaluateJavascript("window.onMayraReply($safe, $offline)", null)
    }

    private fun startGeminiLive() {
        try { speechRecognizer?.cancel(); speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLiveStart = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), permissionCode)
            return
        }
        val key = prefs.getString("apiKey", "") ?: ""
        if (key.isBlank()) {
            liveMode = false
            webView.evaluateJavascript("window.onMayraLiveStatus('پہلے سائیڈ مینو میں Gemini API Key درج کریں', false)", null)
            Toast.makeText(this, "Please add your Gemini API key in Settings", Toast.LENGTH_LONG).show()
            return
        }
        liveSession?.stop()
        val model = prefs.getString("liveModel", "gemini-3.8-live")?.trim().orEmpty().ifBlank { "gemini-3.8-live" }
        val mood = prefs.getString("mood", "natural") ?: "natural"
        val thinking = prefs.getString("thinking", "balanced") ?: "balanced"
        val voice = if ((prefs.getString("voice", "female") ?: "female") == "male") "Puck" else "Aoede"
        val instruction = moodInstruction(mood, thinking) + " Speak directly to the user in natural conversational Urdu. Respond with native audio, not a translated text-to-speech pipeline. Keep responses conversational and relatively concise."
        liveSession = GeminiLiveSession(
            context = this,
            apiKey = key,
            model = model,
            systemInstruction = instruction,
            voiceName = voice,
            onStatus = { message, connected ->
                if (!connected && (message.contains("ناکام") || message.contains("مسئلہ") || message.contains("نہیں ہو سکا"))) liveMode = false
                runOnUiThread { webView.evaluateJavascript("window.onMayraLiveStatus(${JSONObject.quote(message)}, $connected)", null) }
            },
            onTranscript = { role, text -> runOnUiThread { webView.evaluateJavascript("window.onMayraLiveTranscript(${JSONObject.quote(role)}, ${JSONObject.quote(text)})", null) } },
            onTurnComplete = { runOnUiThread { webView.evaluateJavascript("window.onMayraLiveTurnComplete()", null) } }
        )
        liveSession?.start()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition is not available on this device", Toast.LENGTH_LONG).show(); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), permissionCode); return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { webView.evaluateJavascript("window.onMayraListening(true)", null) }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    webView.evaluateJavascript("window.onMayraSpeech(${JSONObject.quote(text)})", null)
                    webView.evaluateJavascript("window.onMayraListening(false)", null)
                }
                override fun onError(error: Int) { webView.evaluateJavascript("window.onMayraListening(false)", null); if (liveMode && liveSession == null && error != SpeechRecognizer.ERROR_CLIENT) webView.postDelayed({ if (liveMode && liveSession == null) startListening() }, 500) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "مائرہ اے آئی سے بات کریں")
            }
            recognizer.startListening(intent)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            if (pendingLiveStart || liveMode) { pendingLiveStart = false; startGeminiLive() } else startListening()
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy(); liveSession?.stop(); liveSession = null; tts?.stop(); tts?.shutdown(); webView.destroy(); executor.shutdownNow(); super.onDestroy()
    }
}
